export const environment = {
  production: true,
  apiUrl: 'http://197.211.216.2:1512',
  version: require("../../package.json").version,
};
