export const FireBaseConfig = {
  apiKey: "AIzaSyAGNiQY5HRnoFGbeEqiE6JRbUY-9l4rzjQ",
  authDomain: "sharestock-ce2b3.firebaseapp.com",
  databaseURL: "https://sharestock-ce2b3.firebaseio.com",
  projectId: "sharestock-ce2b3",
  storageBucket: "sharestock-ce2b3.appspot.com",
  messagingSenderId: "679052913213",
};
