import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
  name: "filterByAll",
})
export class FilterByAll implements PipeTransform {
  transform(items: any, select?: any): any {
    if (select !== "All") {
      return select
        //? items.filter((item) => item["productCategory"] === select)
        ? items.filter((item) => item["productCategory"].toLowerCase().indexOf(select.toLowerCase()) !== -1 || item["productName"].toLowerCase().indexOf(select.toLowerCase()) !== -1)
        : items;
    } else {
      return items;
    }
  }
}
