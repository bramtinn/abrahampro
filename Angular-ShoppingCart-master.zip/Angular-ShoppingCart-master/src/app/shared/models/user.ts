export class User {
  $Key: string;
  userName: string;
  emailId: string;
  password?: string;
  location?: {
    lat: number;
    lon: number;
  };
  phoneNumber: string;
  createdOn?: string;
  isAdmin: boolean;
  avatar?: string;
  Token?: string;
  Retailer: string;
}

export class UserDetail {
  $key: string;
  firstName: string;
  lastName: string;
  userName: string;
  email: string;
  address1: string;
  address2: string;
  country: string;
  state: string;
  zip: number;
}
