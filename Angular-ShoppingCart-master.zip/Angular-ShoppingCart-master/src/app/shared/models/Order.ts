export class Order {
    $Key: string;
    productId: number;
    // address1: string;
    // address2: string;
    // country: string;
    // emailId: string;
    // firstName: string;
    // lastName: string;
    // pollUrl: string;
    // 
    // productName: string;
    // productPrice: number;
    // shippingDate: Number;   
    // state: string;
    // totalPrice: Number;
    // zip: string;
  }
