export class inventory {
  $Key: string;
  productId: number;
  productName: string;
  productCategory: string;
  productPrice: number;
  productDescription: string;
  productImageUrl: string;
  productAdded: number;
  productQuantity: number;
  ratings: number;
  favourite: boolean;
  productSeller: string;
  RetailPrice: number;
  productpriceUSD: number;
  Retailer: string;
}
