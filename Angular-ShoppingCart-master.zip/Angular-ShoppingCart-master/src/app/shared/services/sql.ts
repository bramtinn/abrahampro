import { Injectable } from "@angular/core";
import {
  AngularFireDatabase,
  AngularFireList,
  AngularFireObject,
} from "@angular/fire/database";
import * as http from 'http'; 
import {HttpClientModule, HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
//import { HttpErrorResponse } from '@angular/common/http/response';
import { HttpErrorResponse }  from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/Rx';
import { environment } from '../../../environments/environment';

@Injectable()
export class SqlService {
 // products: AngularFireList<Product>;

  ServiceUrl = environment.apiUrl;
  //ServiceUrl = "http://197.211.216.2:1512";


  constructor(
    private httpClient: HttpClient
  ) {}


 
  async select(company,postdata): Promise<object> {
    console.log(postdata)
    const response = await this.httpClient.post(this.ServiceUrl + company,postdata).toPromise();
    console.log(response)
   return response;
  
  }

  async sqlUpdate(company,postdata): Promise<any> {

           const response =  await this.httpClient.put(this.ServiceUrl + company,postdata).toPromise();
            return response;
    
    }

    async SqlBulk(Statement: string) {
      //this.products.remove(key);
      var postdata = {  
        "Statement": Statement};
        // console.log(postdata)
  
  const response =  await this.httpClient.post(this.ServiceUrl + "/api/SQLBulk",postdata).toPromise();
  return response;
    }

}



