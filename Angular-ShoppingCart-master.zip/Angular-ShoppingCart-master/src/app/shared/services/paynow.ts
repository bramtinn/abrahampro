import { Injectable } from "@angular/core";
import {
  AngularFireDatabase,
  AngularFireList,
  AngularFireObject,
} from "@angular/fire/database";
import { Product } from "../models/product";
import { AuthService } from "./auth.service";
import { ToastrService } from "./toastr.service";
import * as http from 'http'; 
import {HttpClientModule, HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
//import { HttpErrorResponse } from '@angular/common/http/response';
import { HttpErrorResponse }  from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/Rx';
import { environment } from '../../../environments/environment';

@Injectable()
export class PaynowService {
 // products: AngularFireList<Product>;

  ServiceUrl = environment.apiUrl;
 // ServiceUrl = "http://197.211.216.2:1512";



  constructor(

    private authService: AuthService,
    private toastrService: ToastrService,
    private httpClient: HttpClient
  ) {}


 async RequestPayment(Amount: number,OrderNumber: string) {
    //this.product = this.db.object("products/" + key);
    var postdata = {
		OrderNumber: OrderNumber,
        Amount: Amount
};
const response =   await this.httpClient.post(this.ServiceUrl + "/api/Payment",postdata).toPromise();
       console.log(response)
    return response;
  }




  async RequestMPayment(Amount: number,OrderNumber: string, Phone: string) {
    //this.product = this.db.object("products/" + key);
    var postdata = {
		OrderNumber: OrderNumber,
        Amount: Amount,
        PhoneNumber: Phone
};
const response =   await this.httpClient.post(this.ServiceUrl + "/api/Mobile",postdata).toPromise();
       console.log(response)
    return response;
  }

  async CheckPayment(PollUrl: string) {
    //this.product = this.db.object("products/" + key);

const response =   await this.httpClient.post(this.ServiceUrl + "/api/CheckPayment", {"pollUrl": PollUrl}).toPromise();
       console.log(response)
    return response;
  }

 

}



