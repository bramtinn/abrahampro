import { Injectable } from "@angular/core";
//import * as firebase from "firebase/app";
import { Observable, Subject, BehaviorSubject } from "rxjs";
import { User } from "../models/user";
import { AngularFireAuth } from "@angular/fire/auth";
import { Router } from "@angular/router";
import { UserService } from "./user.service";
import { filter, map, tap, shareReplay } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';

export const ANONYMOUS_USER: User = new User();

@Injectable()
export class AuthService {
  user: Observable<User>;
  ServiceUrl = environment.apiUrl;
  //ServiceUrl = "http://197.211.216.2:1512";
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  private subject = new BehaviorSubject<User>(undefined);
  public islog: boolean;
  public USD: boolean;

  user$: Observable<User> = this.subject
    .asObservable()
    .pipe(filter((user) => !!user));

  isLoggedIn$: Observable<boolean> = this.user$.pipe(
    map((user) => !!user.$Key));

  isLoggedOut$: Observable<boolean> = this.isLoggedIn$.pipe(
    map((isLoggedIn) => !isLoggedIn)
    
  );
    
  isAdmin$: Observable<boolean> = this.user$.pipe(
    map((user) =>  
    user.isAdmin)
 
  );


  constructor(
    private firebaseAuth: AngularFireAuth,
    private router: Router,
    private userService: UserService,
    private http: HttpClient
  ) {
    
    // if(localStorage.getItem('currentUser') == null)
    // {
    //   this.subject.next(ANONYMOUS_USER);
    // }
    // else
    // {
    //   this.subject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
      
    //   this.user = this.subject.asObservable().pipe(filter((user) => !!user));;
    //     console.log(this.user)
    // }
    //source.source._value.isAdmin
   // this.user = this.subject["Key"]
  


    //this.user = this.user$;
    
   // if (this.currentUser) {
   //   this.subject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
   // } else {
   //        this.subject.next(ANONYMOUS_USER);
   //    }

     // this.user$.subscribe((user) => {
     //   if (this.user) {
    //      //this.userService
    //        //.isAdmin(user.emailId)
    //        //.snapshotChanges()
    //        //.subscribe((data) => {
      if(localStorage.getItem('currentUser') == null)
      {
        this.subject.next(ANONYMOUS_USER);
        this.islog = false;
      }
      else
      {
        this.islog = true;
        var data = JSON.parse(localStorage.getItem('currentUser'))
        console.log(data)
//         data = JSON.parse(data[0]);
        
      //  data.forEach((el) => {
      //    const y: any = el.payload.toJSON();
          console.log("constructor isAdmin" , data.isAdmin);
          this.subject.next({
            $Key: data.$Key,
            userName: data.username || "Anonymous User",
            emailId: data.username, //data.email,
            phoneNumber: data.phoneNumber,
//            // avatar: user.photoURL,
            isAdmin: data.isAdmin,
            Retailer: data.Retailer
          });
          this.user$ = this.subject
          .asObservable()
          .pipe(filter((user) => !!user));
     //  });
            }
    //        });
    //    } else {
    //      this.subject.next(ANONYMOUS_USER);
    //    }
    //  });
  }

  public get currentUserValue(): User {
    return this.subject.value;
}
  login(username: string, password: string, Key: string, isAdmin: boolean, Retailer: string) {
    console.log(Retailer)
    return this.http.post<any>(this.ServiceUrl +'/users/authenticate', { username, password, Key, isAdmin, Retailer })
        .pipe(map(user => {
         
            // store user details and jwt token in local storage to keep user logged in between page refreshes
            localStorage.setItem('currentUser', JSON.stringify(user));
            this.subject.next(user);
            return user;
        }));
}
  logout() {
   // this.firebaseAuth.signOut().then((res) => {
 
    this.islog = false;
   // this.isAdmin$ = false;
      localStorage.removeItem('currentUser');

      this.subject  = new BehaviorSubject<User>(undefined);
      // this.user$ = this.subject
      // .asObservable()
      // .pipe(filter((user) => !!user))
      
      //this.router.navigate(["/login"]);
      console.log(this.user$)
  //  });
  }

  UsdCurrency(){
    this.USD = true;
  }
  ZimCurrency(){
    this.USD = false;
  }
  

  createUserWithEmailAndPassword(emailID: string, password: string) {
    return this.firebaseAuth.createUserWithEmailAndPassword(emailID, password);
  }

  // signInRegular(email, password) {
  //   const credential = firebase.auth.EmailAuthProvider.credential(
  //     email,
  //     password
  //   );
  //   return this.firebaseAuth.signInWithEmailAndPassword(email, password);
  // }

  // signInWithGoogle() {
  //   return this.firebaseAuth.signInWithPopup(
  //     new firebase.auth.GoogleAuthProvider()
  //   );
  // }
}
