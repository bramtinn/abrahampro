import { Injectable } from "@angular/core";
import {
  AngularFireDatabase,
  AngularFireList,
  AngularFireObject,
} from "@angular/fire/database";
import { Product } from "../models/product";
import { AuthService } from "./auth.service";
import { ToastrService } from "./toastr.service";
import * as http from 'http'; 
import {HttpClientModule, HttpClient, HttpParams, HttpHeaders, HttpEvent, HttpEventType } from '@angular/common/http';
//import { HttpErrorResponse } from '@angular/common/http/response';
import { HttpErrorResponse }  from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/Rx';
import { environment } from '../../../environments/environment';
import { QueryValueType } from '@angular/compiler/src/core';

@Injectable()
export class ProductService {
 // products: AngularFireList<Product>;
 products: any[];
  product: Product;
  ServiceUrl = environment.apiUrl;
  //ServiceUrl = "http://197.211.216.2:1512";

  // favouriteProducts
  favouriteProducts: AngularFireList<FavouriteProduct>;
  cartProducts: AngularFireList<FavouriteProduct>;

  constructor(
    private db: AngularFireDatabase,
    private authService: AuthService,
    private toastrService: ToastrService,
    private httpClient: HttpClient
  ) {}

 async getProducts() {
   // this.products = this.db.list("products");
   
    //this.httpClient.post(this.ServiceUrl + "/api/get2",  postdata)
    //.map((res: any[]) => res)
    //.catch(this.errorhandler);
         var postdata = {    
           Column: " *",
         Table: "product",
       Where: "productQuantity > '0' order by productPrice"};
     const response =  await this.httpClient.post(this.ServiceUrl + "/api/get2",postdata).toPromise();
             this.products = response["recordset"];
    //console.log(this.products);
   //return response;
    return this.products;
  }

  async getmyProducts(Retailer: string) {
    // this.products = this.db.list("products");
    
     //this.httpClient.post(this.ServiceUrl + "/api/get2",  postdata)
     //.map((res: any[]) => res)
     //.catch(this.errorhandler);
          var postdata = {    
            Column: " *",
          Table: "product",
        Where: "Retailer = '"+ Retailer +"' order by productName"};
      const response =  await this.httpClient.post(this.ServiceUrl + "/api/get2",postdata).toPromise();
              this.products = response["recordset"];
     //console.log(this.products);
    //return response;
     return this.products;
   }
  async createProduct(data: Product) {
    //this.products.push(data);
    var postdata = {  
      Table: "product",  
      Column: " [favourite],[productAdded]  ,[productCategory]   ,[productDescription] ,[productId]  ,[productImageUrl] ,[productName] ,[productPrice]  ,[productQuantity] ,[productSeller] ,[ratings],[Retailer],[RetailPrice],[productPriceUSD]",
       Values: "'"+ data.favourite+"','"+ data.productAdded+"','"+ data.productCategory+"','"+ data.productDescription+"','"+ data.productId+"','"+ data.productImageUrl+"','"+ data.productName+"','"+ data.productPrice+"','"+ data.productQuantity+"','"+ data.productSeller+"','"+ data.ratings+"','"+ data.Retailer +"','"+ data.RetailPrice +"','"+ data.productpriceUSD +"'"};
      

const response =  await this.httpClient.post(this.ServiceUrl + "/api/Insert",postdata).toPromise();
return response;
// const formData = new FormData();
// formData.append('Table', "product");
// formData.append('Column', " [favourite],[productAdded]  ,[productCategory]   ,[productDescription] ,[productId]  ,[productImageUrl] ,[productName] ,[productPrice]  ,[productQuantity] ,[productSeller] ,[ratings],[Retailer]");
// formData.append('Values', "'"+ data.favourite+"','"+ data.productAdded+"','"+ data.productCategory+"','"+ data.productDescription+"','"+ data.productId+"','"+ data.productImageUrl+"','"+ data.productName+"','"+ data.productPrice+"','"+ data.productQuantity+"','"+ data.productSeller+"','"+ data.ratings+"','"+ data.Retailer +"'");

// const response = await this.httpClient.post<any>(this.ServiceUrl + "/api/Insert", formData).toPromise();
// return response
// var fd = new FormData();
// var file = new file();
// fd.append('file', file);
// this.httpClient.post(this.ServiceUrl + "/api/Insert", fd, {
//     transformRequest: angular.identity,
//     headers: {'Content-Type': undefined}
// })
// .success(function(){
// })
// .error(function(){
// });
  }

 async getProductById(key: string) {
    //this.product = this.db.object("products/" + key);
    var postdata = {    
      Column: " *",
    Table: "product",
  Where: "[$Key] = '"+ key +"'"};
const response =  await this.httpClient.post(this.ServiceUrl + "/api/get2",postdata).toPromise();
        this.product = response["recordset"];
    return this.product;
  }

  updateProduct(data: Product) {
   // this.products.update(data.$key, data);
  }

  async deleteProduct(key: string) {
    //this.products.remove(key);
    var postdata = {  
      Table: "product",  
       Where: "[$Key] = '"+ key +"'"};
       //console.log(postdata)

const response =  await this.httpClient.post(this.ServiceUrl + "/api/Delete",postdata).toPromise();
  }



  /*
   ----------  Favourite Product Function  ----------
  */

  // Get Favourite Product based on userId
  async getUsersFavouriteProduct() {
    const user = await this.authService.user$.toPromise();
    this.favouriteProducts = this.db.list("favouriteProducts", (ref) =>
      ref.orderByChild("userId").equalTo(user.$Key)
    );
    return this.favouriteProducts;
  }

  // Adding New product to favourite if logged else to localStorage
  addFavouriteProduct(data: Product): void {
    const a: Product[] = JSON.parse(localStorage.getItem("avf_item")) || [];
    a.push(data);
    this.toastrService.wait("Adding Product", "Adding Product as Favourite");
    setTimeout(() => {
      localStorage.setItem("avf_item", JSON.stringify(a));
    }, 1500);
  }

  // Fetching unsigned users favourite proucts
  getLocalFavouriteProducts(): Product[] {
    const products: Product[] =
      JSON.parse(localStorage.getItem("avf_item")) || [];

    return products;
  }

  // Removing Favourite Product from Database
  removeFavourite(key: string) {
    this.favouriteProducts.remove(key);
  }

  // Removing Favourite Product from localStorage
  removeLocalFavourite(product: Product) {
    const products: Product[] = JSON.parse(localStorage.getItem("avf_item"));

    for (let i = 0; i < products.length; i++) {
      if (products[i].productId === product.productId) {
        products.splice(i, 1);
        break;
      }
    }
    // ReAdding the products after remove
    localStorage.setItem("avf_item", JSON.stringify(products));
  }

  /*
   ----------  Cart Product Function  ----------
  */

  // Adding new Product to cart db if logged in else localStorage
  addToCart(data: Product, productList: Product[]): void {
 //   addToCart(data: Product): void {

    var Qty = 0;
    const a: Product[] = JSON.parse(localStorage.getItem("avct_item")) || [];

    a.forEach((product) => {
   
         
      //let obj = productList.find(o => o.$Key === product.$Key);
      let objIndex = productList.findIndex((o => o.$Key === product.$Key));
      if(objIndex != null)
      {
       productList[objIndex].productQuantity = Number(productList[objIndex].productQuantity) - Number(1);
       //console.log(productList[objIndex].productQuantity)
      }
      else{
        this.toastrService.error(
          "Error Finding Quantity",
          "Error Finding the Quantity"
        );
      }
    });

    let objIndex = productList.findIndex((o => o.$Key === data.$Key));
    if(productList[objIndex].productQuantity > 0)
    {
      a.push(data);
      this.toastrService.wait(
        "Adding Product to Trolley",
        "Product Added to the Trolley"
      );
      setTimeout(() => {
        localStorage.setItem("avct_item", JSON.stringify(a));
      }, 500);
    }
    else{
      this.toastrService.error(
        "Product is now out of stock",
        "Product is now out of stock"
      );
      }


  }

  // Removing cart from local
  removeLocalCartProduct(product: Product) {
    const products: Product[] = JSON.parse(localStorage.getItem("avct_item"));

    for (let i = 0; i < products.length; i++) {
      if (products[i].productId === product.productId) {
        products.splice(i, 1);
        break;
      }
    }
    // ReAdding the products after remove
    localStorage.setItem("avct_item", JSON.stringify(products));
  }

  
async updateSql(data: any) {
const response =  await this.httpClient.put(this.ServiceUrl + "/api/Update",data).toPromise();
return response;
}

  // Fetching Locat CartsProducts
  getLocalCartProducts(): Product[] {
    const products: Product[] =
      JSON.parse(localStorage.getItem("avct_item")) || [];

    return products;
  }


  async UploadImage(files: File)
{
 
  const fd = new FormData();
  var apiurl = environment.apiUrl;
   
  fd.append('file',files,files.name)
 // console.log(apiurl);
 const response = await this.httpClient.post(apiurl + '/api/fileupload?finalpath=ID', fd).toPromise();
//  const response = await this.httpClient.post("http://localhost:8081/api/fileupload?finalpath=ID", fd, {
//     reportProgress: true, observe: 'events'
//   }).subscribe( 
//   (event: HttpEvent<any>) => {
   
//        switch (event.type) {
      
//       case HttpEventType.Sent:
     
//         break;
//       case HttpEventType.Response:
//          // console.log(event.body.message);
//          if(event.body.message == "File Limit of 5MB Exceeded.")
//          {
//           //document.getElementById("Perc").innerHTML  = "File Limit of 5MB Exceeded.";
//           //console.log(JSON.stringify(this.FileData))
//           return event.body;
//          }
//          else
//          {
//             //success
//             //console.log(event.body)
//             return event.body;
//         }

//         break;
//       case 1: {
        
//         }
//         break;
//       }
      
//     }
//   ,
//   error => {

//   });
  //console.log(response)
  return response;
}
}




export class FavouriteProduct {
  product: Product;
  productId: string;
  userId: string;
}
