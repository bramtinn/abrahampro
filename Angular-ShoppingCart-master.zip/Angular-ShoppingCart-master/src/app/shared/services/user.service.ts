import { Injectable } from "@angular/core";
import { AngularFireDatabase, AngularFireList } from "@angular/fire/database";
import { filter, map, tap, shareReplay } from "rxjs/operators";
import { HttpClient } from '@angular/common/http';
import {genSaltSync, compareSync, hashSync}  from 'bcryptjs';
import { environment } from '../../../environments/environment';
import * as moment from "moment";
import { User } from "../models/user";

@Injectable()
export class UserService {
  selectedUser: User = new User();
  users: AngularFireList<User>;
 ServiceUrl = environment.apiUrl;
 //ServiceUrl = "http://197.211.216.2:1512";
  user: User;

  location = {
    lat: null,
    lon: null,
  };

  constructor(private db: AngularFireDatabase,
    private http: HttpClient) {
    this.getUsers();
  }

  getUsers() {
    this.users = this.db.list("clients");
    return this.users;
  }

  getUserById(id: string) {}

  async createUser(data: any) {
    data.location = this.location;
    data.createdOn = moment(new Date()).format("X");
    data.isAdmin = false;
    //this.users.push(data);
   
    var postData = {
      Table: "client",
      Column: " [createdon],[email]  ,[isadmin]   ,[uid] ,[verified_email] ,[password] ,[phonenumber]",
      Values: "'"+ data.createdOn+"','"+ data.email+"','"+ data.isAdmin+"','"+ data.uid+"','"+ data.verified_email+"','"+ data.password+"','"+ data.phonenumber+"'"
    };
    
    const response =   await this.http.post<any>(this.ServiceUrl +'/api/insert', postData).toPromise()
    console.log(response)
  }

  PHash(pword: string){
    const saltRounds = genSaltSync(10);
      
    const hashpass = hashSync(pword, saltRounds)
    return hashpass;
  }

  verify(attemtpedpword: string,hashed: string) : boolean{
    return compareSync(attemtpedpword,hashed);
  }

   isAdmin(emailId: string) {
 this.db.list("clients", (ref) =>
       ref.orderByChild("email").equalTo(emailId)
     );
   }

  updateUser(user: User) {
    this.users.update(user.$Key, user);
  }

  setLocation(lat, lon) {
    this.location.lat = lat;
    this.location.lon = lon;
  }
}
