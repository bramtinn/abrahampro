import { Injectable } from "@angular/core";
import * as http from 'http'; 
import {HttpClientModule, HttpClient, HttpParams, HttpHeaders} from '@angular/common/http';
//import { HttpErrorResponse } from '@angular/common/http/response';
import { HttpErrorResponse }  from '@angular/common/http';
import { Observable } from 'rxjs';
import 'rxjs/Rx';
import { environment } from '../../../environments/environment';

@Injectable()
export class OrderService {
 // products: AngularFireList<Product>;

  ServiceUrl = environment.apiUrl;
  //ServiceUrl = "http://197.211.216.2:1512";
  OrderNo: Number;


  constructor(
    private httpClient: HttpClient
  ) {}



}



