import { Component, OnInit } from "@angular/core";
import { NgForm } from "@angular/forms";
import { ProductService } from "src/app/shared/services/product.service";
import { Product } from "src/app/shared/models/product";
import { AuthService } from "../../../../shared/services/auth.service";
import { User } from "../../../../shared/models/user";
import { Alert } from 'selenium-webdriver';
import { environment } from 'src/environments/environment';

declare var $: any;
declare var require: any;
declare var toastr: any;
const shortId = require("shortid");
const moment = require("moment");

@Component({
  selector: "app-add-product",
  templateUrl: "./add-product.component.html",
  styleUrls: ["./add-product.component.scss"],
})
export class AddProductComponent implements OnInit {
  
  product: Product = new Product();
  userL: User;
  files: File;
  Categorys = ["All", "Clothes Kids","Clothes Men","Clothes Women","Cosmetics", "Electronics", "Garden", "Hardware","Home","Jewellery", "Sports","Toys"];

  constructor(private authService: AuthService,private productService: ProductService) {}

  ngOnInit() {
    this.authService.user$.subscribe((user) => {
        
      this.userL = user;
      
    });
    //console.log(this.userL.Retailer)
    this.product.Retailer = this.userL.Retailer;
  }

 async createProduct(productForm: NgForm) {
    productForm.value["productId"] = "PROD_" + shortId.generate();
    productForm.value["productAdded"] = moment().unix();
    productForm.value["ratings"] = Math.floor(Math.random() * 5 + 1);

    if(this.files)
{
 const res = await this.productService.UploadImage(this.files);

 console.log(res);
 productForm.value["productImageUrl"] = environment.apiUrl + res["message"].replace("uploads","");
 
}

    if (productForm.value["productImageUrl"] === undefined) {
      productForm.value["productImageUrl"] =
        "http://via.placeholder.com/640x360/007bff/ffffff";
    }
    
    productForm.value["productpriceUSD"] = Number((this.product.RetailPrice * 1.15).toFixed(2));
    
    // Number((productForm.value["productpriceUSD"] * Number((<HTMLInputElement> document.getElementById("RetailPrice")).value)).toFixed(2));
   
    productForm.value["favourite"] = false;
   

    const date = productForm.value["productAdded"];

    var res = this.productService.createProduct(productForm.value);
      console.log(res);
    this.product = new Product();
    this.product.Retailer = this.userL.Retailer;
    
    $("#exampleModalLong").modal("hide");

    toastr.success(
      "product " + productForm.value["productName"] + " is added successfully",
      "Product Creation"
    );
  }

  fileChangeEvent(fileInput: any) {
    
    if (fileInput.target.files && fileInput.target.files[0]) {
      this.files = fileInput.target.files[0];
        // Size Filter Bytes
        const max_size = 3000000;
        const allowed_types = ['image/png', 'image/jpeg'];
        const max_height = 15200;
        const max_width = 25600;

        if (fileInput.target.files[0].size > max_size) {
           alert('Maximum size allowed is ' + max_size / 1000000 + 'Mb');

            return false;
        }

        // if (!_filename.includes(allowed_types, fileInput.target.files[0].type)) {
        //     alert('Only Images are allowed ( JPG | PNG )');
        //     return false;
        // }
        // const reader = new FileReader();
        // reader.onload = (e: any) => {
        //     const image = new Image();
        //     image.src = e.target.result;
        //     image.onload = rs => {
        //         const img_height = rs.currentTarget['height'];
        //         const img_width = rs.currentTarget['width'];

        //         console.log(img_height, img_width);


        //         if (img_height > max_height && img_width > max_width) {
        //             alert(
        //                 'Maximum dimentions allowed ' +
        //                 max_height +
        //                 '*' +
        //                 max_width +
        //                 'px');
        //             return false;
        //         } else {
        //             const imgBase64Path = e.target.result;
        //             this.product.productImageUrl = imgBase64Path
        //             // this.previewImagePath = imgBase64Path;
        //         }
        //     };
        // };

        //reader.readAsDataURL(fileInput.target.files[0]);
    }

  }
  Pricing()
{
 
  //this.product.productpriceUSD = Number((this.product.productpriceUSD * 1.15).toFixed(2));
  var price = this.product.RetailPrice * 1.15;
  this.product.productPrice =  Number((price * Number((<HTMLInputElement> document.getElementById("productpriceUSD")).value)).toFixed(2));
 
}


}


