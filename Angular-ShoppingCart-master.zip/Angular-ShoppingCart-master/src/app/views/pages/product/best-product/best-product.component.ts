import { TranslateService } from "src/app/shared/services/translate.service";
import { Component, OnInit } from "@angular/core";
import { Product } from "src/app/shared/models/product";
import { ProductService } from "src/app/shared/services/product.service";
import { ToastrService } from "src/app/shared/services/toastr.service";
import { AuthService } from "../../../../shared/services/auth.service";
import {ActivatedRoute} from "@angular/router";

@Component({
  selector: "app-best-product",
  templateUrl: "./best-product.component.html",
  styleUrls: ["./best-product.component.scss"],
})
export class BestProductComponent implements OnInit {
  bestProducts: Product[] = [];
  productList: Product[];
  originalList: Product[];
  options: any;
  loading = false;
  brands = ["All", "ShareStock", "Realme", "Nokia", "Motorolla","Sports"];
  Categorys = ["All", "Clothes Kids","Clothes Men","Clothes Women","Cosmetics", "Electronics", "Garden", "Hardware","Home","Jewellery", "Sports","Toys"];

  selectedBrand: "All";
  selectedCategory: "All";
  Search: "All";
  USD: boolean;

  page = 1;
  constructor(
    private productService: ProductService,
    private toasterService: ToastrService,
    public translate: TranslateService,
    public authService: AuthService,
    route:ActivatedRoute,
  ) {
    route.params.subscribe(val => {
      // put the code from `ngOnInit` here
      this.authService.isLoggedIn$.subscribe();
      this.authService.isAdmin$.subscribe();
      });
  }

  ngOnInit() {


    console.log(this.authService.isLoggedIn$);
        this.options = {
      dots: false,
      responsive: {
        0: { items: 1, margin: 5 },
        430: { items: 2, margin: 5 },
        550: { items: 3, margin: 5 },
        670: { items: 4, margin: 5 },
      },
      autoplay: true,
      loop: true,
      autoplayTimeout: 5000,
      lazyLoad: true,
    };
    this.getAllProducts();
    this.USD = this.authService.USD
    if (this.USD){(<HTMLInputElement>document.getElementById("Currency")).value = "USD"}
  }

  async getAllProducts() {
    this.loading = true;
    const x = await this.productService.getProducts();
    this.productList = x;
    this.originalList = this.productList;
  
   this.productList.sort((b, a) => b.productPrice - a.productPrice);
//    this.productList.sort(function(a, b){
//     if(a.productName < b.productName) { return -1; }
//     if(a.productName > b.productName) { return 1; }
//     return 0;
// })
   // const y = await this.productService.getProducts();
    this.bestProducts = x;
    //console.log(this.bestProducts)
   // this.bestProducts = x;
    // x.snapshotChanges().subscribe(
    //   (product) => {
         this.loading = false;
    //     this.bestProducts = [];
    //     for (let i = 0; i < 5; i++) {
    //       const y = product[i].payload.toJSON();
    //       y["$key"] = product[i].key;
    //       this.bestProducts.push(y as Product);
    //     }
    //     // product.forEach(element => {
    //     //   const y = element.payload.toJSON();
    //     //   y["$key"] = element.key;
    //     //   this.bestProducts.push(y as Product);
    //     // });
    //   },
    //   (error) => {
    //     this.toasterService.error("Error while fetching Products", error);
    //   }
    // );
  }
  removeProduct(key: string) {
    console.log(key)
    this.productService.deleteProduct(key);
  }

  addFavourite(product: Product) {
    this.productService.addFavouriteProduct(product);
  }

  addToCart(product: Product) {
        //this.cartProducts.forEach((product) => {
         
     // let obj = this.productList.find(o => o.$Key === product.$Key);
    this.productService.addToCart(product, this.originalList);
  }

  Currency(){
    if((<HTMLInputElement>document.getElementById("Currency")).value =="USD")
    {
        this.authService.USD = true;
        this.USD = true;
    }
    else{
      this.authService.USD = false;
      this.USD = false;
    }
    console.log(this.authService.USD)
  }
}
