import { Product } from "../../../../../shared/models/product";
import { ProductService } from "../../../../../shared/services/product.service";
import { SqlService } from "../../../../../shared/services/sql";
import { Component, OnInit, ViewChild } from "@angular/core";
import * as jspdf from "jspdf";
import html2canvas from "html2canvas";
import { PaynowService } from 'src/app/shared/services/paynow';
import {Observable,interval} from 'rxjs';
import { AuthService } from "../../../../../shared/services/auth.service";

declare var $: any;
@Component({
  selector: "app-result",
  templateUrl: "./result.component.html",
  styleUrls: ["./result.component.scss"]
})
export class ResultComponent implements OnInit {
  products: any[];
  date: number;
  totalPrice = 0;
  PaymentMade = false;
  Status = "";
  sub: any;
  USD: boolean;
  ReceiptNo: Number;



   constructor(
    private productService: ProductService,
    private sql: SqlService,
    private paynow: PaynowService,
    public authService: AuthService
    )  {
    /* Hiding Billing Tab Element */
    document.getElementById("productsTab").style.display = "none";
    document.getElementById("shippingTab").style.display = "none";
    document.getElementById("billingTab").style.display = "none";
    document.getElementById("resultTab").style.display = "block";
    
    this.USD = this.authService.USD;

    //this.products = productService.getLocalCartProducts();
     //this.getorder();




  }

  async ngOnInit() {
 await this.getorder();

    this.CheckPayment()
   
    if(!this.PaymentMade)
    {
    this.sub = Observable.interval(10000)
    .subscribe((val) => { this.CheckPayment() });
    }

  }

  async getorder(){
    var orderNo = localStorage.getItem("orderNo");
    var postData =  {
      Column: " *",
       Table: "orders ",
       Where: "orderno = '"+ orderNo +"'"
       }
      
  
       const result =  await this.sql.select("/api/get", postData);
       
       this.products = result["recordset"];

       this.products.forEach((product) => {
        if(this.USD){ this.totalPrice += product.productpriceUSD;}
        if(!this.USD){ this.totalPrice += product.productPrice;}
       });
       this.totalPrice = Number(this.totalPrice.toFixed(2));
       this.date = Date.now();
  }
  downloadReceipt() {
    const data = document.getElementById("receipt");
    // console.log(data);

    html2canvas(data).then((canvas) => {
      // Few necessary setting options
      const imgWidth = 208;
      const pageHeight = canvas.height;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      const heightLeft = imgHeight;

      const contentDataURL = canvas.toDataURL("image/png");
      const pdf = new jspdf("p", "mm", "a4"); // A4 size page of PDF
      const position = 0;
      pdf.addImage(contentDataURL, "PNG", 0, position, imgWidth, imgHeight);
      pdf.save("ZimTrolley.pdf"); // Generated PDF
    });
  }


  async CheckPayment() {
    var orderNo = localStorage.getItem("orderNo");
    console.log(localStorage.getItem("PollURL"))
    if(localStorage.getItem("PollURL") == "POD")
    {
      
          this.PaymentMade = true;
          //this.sub.unsubscribe();
          const a: Product[] = [];
          localStorage.setItem("avct_item", JSON.stringify(a));
    }
    else
    {
    const result =  await this.paynow.CheckPayment(localStorage.getItem("PollURL"));
    this.Status = result["Status"] ;

    var  postData =  {
      Column: "PaymentStatus = '"+  result["Status"]  +"'",
       Table: "orders",
       Where: "orderno = '"+ orderNo +"'"
       }
     const result1 =  await this.sql.sqlUpdate("/api/Update", postData);

    if(result["Status"] == "awaiting delivery")
       {
        this.sub.unsubscribe();
          this.PaymentMade = true
          const a: Product[] = [];
          localStorage.setItem("avct_item", JSON.stringify(a));
       }
       else
       {
        
        this.PaymentMade = false
       }
      }

      
      if(this.PaymentMade == true)
      {
        
        var postData =  {
          Column: " *",
           Table: "sysvalues ",
           Where: "description = 'Receipt'"
           }
           console.log(postData)
           const result =  await this.sql.select("/api/get", postData);
           console.log(result)
           this.ReceiptNo  = +result["recordset"][0].Value;
          
          //this.ord.OrderNo =  +result["recordset"][0].Value;
          localStorage.setItem("Receipt", this.ReceiptNo .toString());
           var neword = +this.ReceiptNo  + +"1";
           
           postData =  {
            Column: "Value = '"+ neword  +"'",
             Table: "sysvalues",
             Where: "description = 'Receipt'"
             }
           const result1 =  await this.sql.sqlUpdate("/api/Update", postData);
      }
    // var postData =  {
    //   Column: "Top (1) *",
    //    Table: "results ",
    //    Where: "reference = 'Invoice72' order by indno desc"
    //    }

    //    const result =  await this.sql.sql("/api/get", postData);
    //    this.Status = result["recordset"][0].Status;
    //    if(result["recordset"][0].Status == "Awaiting Delivery")
    //    {
    //       console.log("True")
    //       this.PaymentMade = true
    //    }
    //    else
    //    {
    //     console.log("False")
    //     this.PaymentMade = false
    //    }

  }

}
