import { Product } from "../../../../../shared/models/product";
import { Order } from "../../../../../shared/models/Order";
import { ShippingService } from "../../../../../shared/services/shipping.service";
import { UserDetail, User } from "../../../../../shared/models/user";
import { AuthService } from "../../../../../shared/services/auth.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { NgForm } from "@angular/forms";
import { Router } from "@angular/router";
import { ProductService } from "../../../../../shared/services/product.service";
import { map } from "rxjs/operators";
import { PaynowService } from "../../../../../shared/services/paynow";
import { stringify } from 'querystring';
import { SqlService } from "../../../../../shared/services/sql";
import { OrderService } from "../../../../../shared/services/Orders";
import { ToastrService } from "../../../../../shared/services/toastr.service";

@Component({
  selector: "app-shipping-details",
  templateUrl: "./shipping-details.component.html",
  styleUrls: ["./shipping-details.component.scss"],
})
export class ShippingDetailsComponent implements OnInit {
  userL: User;

  orders: any[];
  userDetail: UserDetail;
  userDetailB: UserDetail;
USD: boolean;

  products: Product[];

  constructor(
    private authService: AuthService,
    private shippingService: ShippingService,
    productService: ProductService,
    private router: Router,
    private paynow: PaynowService,
    private sql: SqlService,
    private ord: OrderService,
    private toastrService: ToastrService,
  ) {
    /* Hiding products Element */
    document.getElementById("productsTab").style.display = "none";
    document.getElementById("shippingTab").style.display = "block";
    document.getElementById("productsTab").style.display = "none";
    document.getElementById("resultTab").style.display = "none";

    this.userDetail = new UserDetail();
    this.userDetailB = new UserDetail();
    this.products = productService.getLocalCartProducts();

  }

  ngOnInit() {
    this.USD = this.authService.USD;
    // this.authService.user$.pipe(
    //   map((user) => {
        
    //     this.userL = user;
        
    //   })
    // );
    this.authService.user$.subscribe((user) => {
        
        this.userL = user;
        
      });
    //console.log(this.userL)
  }

  async updateUserDetails(form: NgForm) {
    
    if(form.valid)
    {
  // console.log(this.products)
    const products = [];
    let SQL: string = "";

    let totalPrice = 0;
let i = 0

var postData =  {
  Column: " *",
   Table: "sysvalues ",
   Where: "description = 'Orders'"
   }

   const result =  await this.sql.select("/api/get", postData);

  var orderNo: Number = +result["recordset"][0].Value;
  //this.ord.OrderNo =  +result["recordset"][0].Value;
  localStorage.setItem("orderNo", orderNo.toString());
   var neword = +orderNo + +"1";

   postData =  {
    Column: "Value = '"+ neword  +"'",
     Table: "sysvalues",
     Where: "description = 'Orders'"
     }
   const result1 =  await this.sql.sqlUpdate("/api/Update", postData);

    this.products.forEach((product) => {
      var data1 = new Order;
    //  data = form.value;
    //  data.emailId = this.userDetail.email;
    //   //delete product.$key;
      if(this.USD){totalPrice += product.productpriceUSD;} 
      if(!this.USD){totalPrice += product.productPrice;} 
    //  // this.data. = products;
    data1.$Key = product.$Key;
      data1.productId = product.productId;
      products.push(product);
    //  data.productName = product.productName;
    //  data.productPrice = product.productPrice;
    // // this.data.productId = product.productId;
    //  //this.data.productId = product.productId;
    //   data.totalPrice = totalPrice;
  
    //   data.shippingDate = Date.now();
    //   //products.push(product);
    //  console.log(data.totalPrice)
    //   //products.push(data);
    //   //console.log(products)
  //   data.$key = "1";
  //   data.productId = 1;
  //   data.productName = "1";
  //   data.productPrice = 1 ;
  //   data.firstName = "1";
  //   data.lastName = "1";
  //   data.emailId = "1";
  //   data.address1 = "1";
  //   data.address2 = "1";
  //   data.country = "1";
  //   data.state = "1";
  //   data.zip = "1";
  //   data.pollUrl = "1";
  //   data.totalPrice = 1;
  //   data.shippingDate=78;
  //  console.log(data)

    //this.orders.push(data)
  //     i = i + 1;

  SQL = SQL + `INSERT INTO [dbo].[Orders]
  ([OrderNo]
  ,[ProductKey]
  ,[productName]
  ,[productCategory]
  ,[productId]
  ,[productPrice]
  ,[productQuantity]
  ,[productpriceUSD]
  ,[Status]
  ,[PaymentStatus]
  ,[Currency]
  ,[Seller]
  ,[shippingDate]
  ,[totalPrice]
  ,[emailId]
  ,[userId]
  ,[firstName]
  ,[lastName]
  ,[email]
  ,[address1]
  ,[address2]
  ,[city]
  ,[country]
  ,[BillfirstName]
  ,[BilllastName]
  ,[Billemail]
  ,[Billaddress1]
  ,[Billaddress2]
  ,[Billcity]
  ,[Billcountry]
  ,[Retailer])`;
  SQL = SQL + `     VALUES
  ('`+ orderNo +`'
  ,'`+ product.$Key +`'
  ,'`+ product.productName +`'
  ,'`+ product.productCategory +`'
  ,'`+ product.productId +`'
  ,'`+ product.productPrice +`'
  ,'`+ product.productQuantity +`'
  ,'`+ product.productpriceUSD +`'
  ,'New'
  ,'New'
  ,'`+ this.authService.USD +`'
  ,'`+ product.productSeller +`'
  ,'`+ Date.now() +`'
  ,'`+ totalPrice +`'
  ,'`+ this.userL.emailId +`'
  ,'`+ this.userL.$Key +`'
  ,'`+ this.userDetail.firstName +`'
  ,'`+ this.userDetail.lastName +`'
  ,'`+ this.userDetail.email +`'
  ,'`+ this.userDetail.address1 +`'
  ,'`+ this.userDetail.address2 +`'
  ,'`+ this.userDetail.state +`'
  ,'`+ this.userDetail.country +`'
  ,'`+ this.userDetailB.firstName +`'
  ,'`+ this.userDetailB.lastName +`'
  ,'`+ this.userDetailB.email +`'
  ,'`+ this.userDetailB.address1 +`'
  ,'`+ this.userDetailB.address2 +`'
  ,'`+ this.userDetailB.state +`'
  ,'`+ this.userDetailB.country +`'
  ,'`+ product.Retailer +`')`;
    });
    const data = {
      ...form.value,
      emailId: this.userL.emailId,
      userId: this.userL.$Key,
      products,
      totalPrice,
      shippingDate: Date.now(),
    };
    console.log(data)

    const resultupdate =  await this.sql.SqlBulk(SQL);
//console.log(resultupdate)
    
  //   const res = await this.paynow.RequestPayment(totalPrice,"73")
  //   // console.log(res["__zone_symbol__value"].status)
  //    console.log(res)
  //   // if (res["success"] === "true")
  //  //  {
  //      console.log(res["pollUrl"])
  //      localStorage.setItem("PollURL", res["pollUrl"]);
  //      //window.open(res["redirectUrl"] , "_blank");
  //      window.location.href = res["redirectUrl"];
  //   // }
  //   //this.shippingService.createshippings(data);

  if(resultupdate["status"] == 200)
  {
    console.log(this.ord.OrderNo )

     this.router.navigate([
       "checkouts",
       { outlets: { checkOutlet: ["billing-details"] } },
     ]);
    }
    else{
      console.log(resultupdate["success"])
    }
  }
  else
  {
    this.toastrService.wait(
      "Please enter all required fields",
      ""
    );
  }
  }

}
