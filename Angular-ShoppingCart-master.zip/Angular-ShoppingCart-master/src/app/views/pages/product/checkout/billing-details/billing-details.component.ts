import { ProductService } from "../../../../../shared/services/product.service";
import { Product } from "../../../../../shared/models/product";
import { BillingService } from "../../../../../shared/services/billing.service";
import { Component, OnInit, ViewChild } from "@angular/core";
import { User, UserDetail } from "../../../../../shared/models/user";
import { AuthService } from "../../../../../shared/services/auth.service";
import { Router } from "@angular/router";
import { NgForm } from "@angular/forms";
import { map } from "rxjs/operators";
import { PaynowService } from "../../../../../shared/services/paynow";
import { SqlService } from "../../../../../shared/services/sql";
import { OrderService } from "../../../../../shared/services/Orders";

@Component({
  selector: "app-billing-details",
  templateUrl: "./billing-details.component.html",
  styleUrls: ["./billing-details.component.scss"],
})
export class BillingDetailsComponent implements OnInit {
  userDetails: User;
  products: Product[];
  userDetail: UserDetail;
  Poptions = true;
   phoneNumber: string;
   USD: boolean;

  constructor(
    public authService: AuthService,
    private billingService: BillingService,
    productService: ProductService,
    private router: Router,
    private paynow: PaynowService,
    private sql: SqlService,
    private ord: OrderService
  ) {
    /* Hiding Shipping Tab Element */
    document.getElementById("productsTab").style.display = "none";
    document.getElementById("shippingTab").style.display = "none";
    document.getElementById("billingTab").style.display = "block";
    document.getElementById("resultTab").style.display = "none";

    this.userDetail = new UserDetail();
    this.products = productService.getLocalCartProducts();
    authService.user$.pipe(
      map((user) => {
        this.userDetails = user;
      })
    );
  }

  ngOnInit() {
    this.USD = this.authService.USD;
  }
 
  check(value: string)
{
  
  if (value == "Ecocash")
  {
    this.Poptions = true;
  }
  else{
    this.Poptions = false;
  }
  console.log(this.Poptions)
}

updateUserDetails2(form: NgForm) {
  //var radios = document.getElementsByName('PType');
  
  //console.log()
  //const forms = document.forms.Pay;
  //const radios = form.elements.characters;
}
  async updateUserDetails(form: NgForm) {
  //   const data = form.value;
  //  // data["emailId"] = this.userDetail.emailId;
  //   data["userId"] = 1;//this.userDetail.$key;
     let totalPrice = 0;
  //   const products = [];
     this.products.forEach((product) => {
  //     delete product["$key"];
       totalPrice += product.productPrice;
  //     products.push(product);
     });

  //   data["products"] = products;

  //   data["totalPrice"] = totalPrice;

  //   data["billingDate"] = Date.now();

  //   this.billingService.createBillings(data);
  
     var orderNo = localStorage.getItem("orderNo");

if(form.value.PType =="Ecocash")
{
    const res = await this.paynow.RequestMPayment(totalPrice,orderNo,(<HTMLInputElement>document.getElementById("phonenum")).value)

     //  console.log(res)
       localStorage.setItem("PollURL", res["pollUrl"]);

       //window.location.href = res["redirectUrl"];
     var  postData =  {
        Column: "pollUrl = '"+  res["pollUrl"]  +"'",
         Table: "orders",
         Where: "orderno = '"+ orderNo +"'"
         }
       const result1 =  await this.sql.sqlUpdate("/api/Update", postData);
       this.router.navigate([
        "checkouts",
        { outlets: { checkOutlet: ["result"] } },
      ]);
 }else
  if(form.value.PType == "PayNow")
 {
   console.log("In")
  const res = await this.paynow.RequestPayment(totalPrice,orderNo)
  //   // console.log(res["__zone_symbol__value"].status)
      console.log(res)
  // if (res["success"] === "true")
  //  //  {
  //      console.log(res["pollUrl"])
  //      localStorage.setItem("PollURL", res["pollUrl"]);
  //      //window.open(res["redirectUrl"] , "_blank");
  //      window.location.href = res["redirectUrl"];
  //   // }
  //  console.log(res)
    localStorage.setItem("PollURL", res["pollUrl"]);

    //window.location.href = res["redirectUrl"];
  var  postData =  {
     Column: "pollUrl = '"+  res["pollUrl"]  +"'",
      Table: "orders",
      Where: "orderno = '"+ orderNo +"'"
      }
    const result1 =  await this.sql.sqlUpdate("/api/Update", postData);
    window.location.href = res["redirectUrl"];
 }else
  if(form.value.PType =="Cash")
 {
  localStorage.setItem("PollURL", "POD");

  //window.location.href = res["redirectUrl"];
var  postData =  {
   Column: "pollUrl = 'POD',PaymentStatus = 'POD'",
    Table: "orders",
    Where: "orderno = '"+ orderNo +"'"
    }
  const result1 =  await this.sql.sqlUpdate("/api/Update", postData)
  this.router.navigate([
    "checkouts",
    { outlets: { checkOutlet: ["result"] } },
  ]);
 }

  }
}

