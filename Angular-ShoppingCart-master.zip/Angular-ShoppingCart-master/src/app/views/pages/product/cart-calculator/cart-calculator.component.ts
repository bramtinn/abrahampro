import {
  Component,
  OnInit,
  Input,
  OnChanges,
  SimpleChange,
  SimpleChanges,
} from "@angular/core";
import { Product } from "../../../../shared/models/product";
import { AuthService } from "../../../../shared/services/auth.service";

@Component({
  selector: "app-cart-calculator",
  templateUrl: "./cart-calculator.component.html",
  styleUrls: ["./cart-calculator.component.scss"],
})
export class CartCalculatorComponent implements OnInit, OnChanges {
  @Input() products: Product[];

  totalValue = 0;
  USD: boolean;
  constructor(public authService: AuthService) {}

  ngOnChanges(changes: SimpleChanges) {
    const dataChanges: SimpleChange = changes.products;

    const products: Product[] = dataChanges.currentValue;
    this.totalValue = 0;
    this.USD = this.authService.USD

    if (this.USD)
    {
      products.forEach((product) => {
        this.totalValue += Number(product.productpriceUSD.toFixed(2));
  });
    }
      else
      {
        products.forEach((product) => {
          this.totalValue += Number(product.productPrice.toFixed(2));
    });
    }
    this.totalValue  = Number(this.totalValue.toFixed(2));
  }

  ngOnInit() {
    
   
  }
}
