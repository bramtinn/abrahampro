import { Component, OnInit } from "@angular/core";
import { Product } from "../../../../shared/models/product";
import { AuthService } from "../../../../shared/services/auth.service";
import { ProductService } from "../../../../shared/services/product.service";
import { ToastrService } from "src/app/shared/services/toastr.service";
import {  User } from "../../../../shared/models/user";
import { HIGH_CONTRAST_MODE_ACTIVE_CSS_CLASS } from '@angular/cdk/a11y/high-contrast-mode/high-contrast-mode-detector';
@Component({
  selector: "app-product-list",
  templateUrl: "./product-list.component.html",
  styleUrls: ["./product-list.component.scss"],
})
export class ProductListComponent implements OnInit {
  productList: Product[];
  loading = false;
  userL: User;
  brands = ["All", "ShareStock", "Realme", "Nokia", "Motorolla","Sports"];
  Categorys = ["All", "Clothes Kids","Clothes Men","Clothes Women","Cosmetics", "Electronics", "Garden", "Hardware","Home","Jewellery", "Sports","Toys"];
  //isAdmin;

  selectedBrand: "All";
  selectedCategory: "All";
  Search: "All";
  
  page = 1;
  constructor(
    public authService: AuthService,
    private productService: ProductService,
    private toastrService: ToastrService
  ) {
    //this.isAdmin = JSON.parse(localStorage.getItem('currentUser'))['isAdmin'];
   // this.isAdmin = this.authService.isAdmin$;
   // console.log(this.isAdmin)
  }

  ngOnInit() {
    //console.log(this.authService.isLoggedIn$)
 this.getAllProducts();
  }

  async getAllProducts() {
    // this.spinnerService.show();
    this.authService.user$.subscribe((user) => {
        
      this.userL = user;
      
    });
    this.loading = true;
    const x = await this.productService.getmyProducts(this.userL.Retailer);
    this.productList = x;
    this.loading = false;

    // x.snapshotChanges().subscribe(
    //   (product) => {
    //     this.loading = false;
    //     // this.spinnerService.hide();
    //     this.productList = [];
    //     product.forEach((element) => {
    //       const y = element.payload.toJSON();
    //       y["$key"] = element.key;
    //       this.productList.push(y as Product);
    //       console.log(this.productList)
    //     });
    //   },
    //   (err) => {
    //     this.toastrService.error("Error while fetching Products", err);
    //   }
    // );
  }

  removeProduct(key: string) {
    console.log(key)
    this.productService.deleteProduct(key);
    
  }

  addFavourite(product: Product) {
    this.productService.addFavouriteProduct(product);
  }

  addToCart(product: Product) {
    this.productService.addToCart(product,this.productList);
  }
}
