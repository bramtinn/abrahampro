import { Component, OnInit } from "@angular/core";
import { inventory } from "../../../../shared/models/Inventory";
import { AuthService } from "../../../../shared/services/auth.service";
import { ProductService } from "../../../../shared/services/product.service";
import { ToastrService } from "src/app/shared/services/toastr.service";
import {  User } from "../../../../shared/models/user";
import { Product } from "../../../../shared/models/product";
import { NgForm } from "@angular/forms";
import { HIGH_CONTRAST_MODE_ACTIVE_CSS_CLASS } from '@angular/cdk/a11y/high-contrast-mode/high-contrast-mode-detector';
import { environment } from 'src/environments/environment';

declare var $: any;
declare var toastr: any;
@Component({
  selector: "app-product-Inventory",
  templateUrl: "./Inventory.component.html",
  styleUrls: ["./Inventory.component.scss"],
})
export class InventoryListComponent implements OnInit {
  productList: inventory[];
  product: Product = new Product();
  userL: User;
  loading = false;
  files: File;
  brands = ["All", "ShareStock", "Realme", "Nokia", "Motorolla","Sports"];
  Categorys = ["All", "Clothes Kids","Clothes Men","Clothes Women","Cosmetics", "Electronics", "Garden", "Hardware","Home","Jewellery", "Sports","Toys"];
  //isAdmin;
  

  selectedBrand: "All";
  selectedCategory: "All";

  page = 1;
  constructor(
    public authService: AuthService,
    private productService: ProductService,
    private toastrService: ToastrService
  ) {
    //this.isAdmin = JSON.parse(localStorage.getItem('currentUser'))['isAdmin'];
   // this.isAdmin = this.authService.isAdmin$;
   // console.log(this.isAdmin)
  }

  ngOnInit() {
    console.log(this.authService.isLoggedIn$)
 this.getAllProducts();
  }

  async getAllProducts() {
    // this.spinnerService.show();
    this.authService.user$.subscribe((user) => {
        
      this.userL = user;
      
    });
    this.loading = true;
    const x = await this.productService.getmyProducts(this.userL.Retailer);
    this.productList = x;
    this.loading = false;

    // x.snapshotChanges().subscribe(
    //   (product) => {
    //     this.loading = false;
    //     // this.spinnerService.hide();
    //     this.productList = [];
    //     product.forEach((element) => {
    //       const y = element.payload.toJSON();
    //       y["$key"] = element.key;
    //       this.productList.push(y as Product);
    //       console.log(this.productList)
    //     });
    //   },
    //   (err) => {
    //     this.toastrService.error("Error while fetching Products", err);
    //   }
    // );
  }

  removeProduct(key: string) {
    console.log(key)
    this.productService.deleteProduct(key);
  }

 async Costs()
  {
    for (let index in this.productList) {
     this.productList[index].productpriceUSD = Number((this.productList[index].RetailPrice * 1.15).toFixed(2));
     this.productList[index].productPrice =  Number((this.productList[index].productpriceUSD * Number((<HTMLInputElement> document.getElementById("rate")).value)).toFixed(2));
     //console.log(this.productList[index].RetailPrice * 1.15)
     var postdata = {  
      Table: "product",  
      Column: " [productPrice] = '"+ this.productList[index].productPrice +"' ,[productQuantity] = '"+ this.productList[index].productQuantity +"',[retailPrice] = '"+ this.productList[index].RetailPrice +"', [productpriceUSD] = '"+ this.productList[index].productpriceUSD +"'",
      Where: "[$Key] = '"+ this.productList[index].$Key +"'"};
      var result = await this.productService.updateSql(postdata);
    }


  }
  async Update(id: any)
  {
   // console.log(this.productList[id].productQuantity)

    var postdata = {  
      Table: "product",  
      Column: " [productPrice] = '"+ this.productList[id].productPrice +"' ,[productQuantity] = '"+ this.productList[id].productQuantity +"',[retailPrice] = '"+ this.productList[id].RetailPrice +"', [productpriceUSD] = '"+ this.productList[id].productpriceUSD +"'",
      Where: "[$Key] = '"+ this.productList[id].$Key +"'"};
      var result = await this.productService.updateSql(postdata);
       //console.log(result)
  }

  Change(id: any)
  {
    this.productList[id].productQuantity = Number((<HTMLInputElement> document.getElementById("qty"+id)).value);
   
  }
  Price(id: any)
  {
    this.productList[id].RetailPrice = Number((<HTMLInputElement> document.getElementById("price"+id)).value);
    var rate;
    rate = this.productList[id].productPrice / this.productList[id].productpriceUSD;
    this.productList[id].productpriceUSD = Number((this.productList[id].RetailPrice * 1.15).toFixed(2));
    this.productList[id].productPrice =  Number(this.productList[id].productpriceUSD) * Number((rate).toFixed(2));

  }

  products(id: any)
  {
      this.product = this.productList[id];
  }



  fileChangeEvent(fileInput: any) {
    
    if (fileInput.target.files && fileInput.target.files[0]) {
        // Size Filter Bytes
        this.files = fileInput.target.files[0];
      
    //     const max_size = 5000;
    //     const allowed_types = ['image/png', 'image/jpeg'];
    //     const max_height = 15200;
    //     const max_width = 25600;

    //     if (fileInput.target.files[0].size > max_size) {
    //        alert('Maximum size allowed is '+  max_size / 1000 + 'Mb');

    //         return false;
    //     }

    //     // if (!_filename.includes(allowed_types, fileInput.target.files[0].type)) {
    //     //     alert('Only Images are allowed ( JPG | PNG )');
    //     //     return false;
    //     // }
    //     const reader = new FileReader();
    //     reader.onload = (e: any) => {
    //         const image = new Image();
    //         image.src = e.target.result;
    //         image.onload = rs => {
    //             const img_height = rs.currentTarget['height'];
    //             const img_width = rs.currentTarget['width'];

    //             console.log(img_height, img_width);


    //             if (img_height > max_height && img_width > max_width) {
    //                 alert(
    //                     'Maximum dimentions allowed ' +
    //                     max_height +
    //                     '*' +
    //                     max_width +
    //                     'px');
    //                 return false;
    //             } else {
    //                 const imgBase64Path = e.target.result;
    //                 this.product.productImageUrl = imgBase64Path
    //                 // this.previewImagePath = imgBase64Path;
    //             }
    //         };
    //     };

    //     reader.readAsDataURL(fileInput.target.files[0]);
     }

  }
  Pricing()
{
 
  //this.product.productpriceUSD = Number((this.product.productpriceUSD * 1.15).toFixed(2));
  var price = this.product.productpriceUSD * 1.15;
  this.product.productPrice =  Number((price * Number((<HTMLInputElement> document.getElementById("rate")).value)).toFixed(2));
 
}


async createProduct(productForm: NgForm) {
 
if(!this.files == null)
{
 const res = await this.productService.UploadImage(this.files);


 this.product.productImageUrl = environment.apiUrl + res["message"].replace("uploads","");
 console.log(this.product.productImageUrl);
}

  var postdata = {  
    Table: "product",  
    Column: " [productCategory] = '"+ this.product.productCategory +"',[productDescription] = '"+ this.product.productDescription +"', [productImageUrl] = '"+ this.product.productImageUrl +"',[productName] = '"+ this.product.productName +"'",
    Where: "[$Key] = '"+ this.product.$Key +"'"};
    var result = await this.productService.updateSql(postdata);
      console.log(result)
      if(result["status"] == 200)
      {
        toastr.success(
          "product " + productForm.value["productName"] + "is updated successfully",
          "Product updated"
        );
  this.product = new Product();
  $('#UpdateProduct').modal('hide');
      }
      else
      {
        toastr.error(
          "Failed to Update Product",
          "Product updated Failed"
        );
      }

  //$("#UpdateProduct").modal("hide");


}
}
