import { Component, OnInit } from "@angular/core";
import { Product } from "../../../../shared/models/product";
import { ProductService } from "../../../../shared/services/product.service";
import { AuthService } from "../../../../shared/services/auth.service";
import { Location } from '@angular/common';

@Component({
  selector: "app-cart-products",
  templateUrl: "./cart-products.component.html",
  styleUrls: ["./cart-products.component.scss"],
})
export class CartProductsComponent implements OnInit {
  cartProducts: Product[];
  productList: Product[];
  showDataNotFound = true;
USD: boolean;
  // Not Found Message
  messageTitle = "No Products Found in Trolley";
  messageDescription = "Please, Add Products to Trolley";

  constructor(private productService: ProductService,public authService: AuthService, private location: Location) {}

  async ngOnInit() {
    this.USD = this.authService.USD
    this.getCartProduct();
    await this.getAllProducts();

    this.cartProducts.forEach((product) => {
         
      let obj = this.productList.find(o => o.$Key === product.$Key);

      if(obj == null)
      {
        this.removeCartProduct(product);
      }
      else{
        if(obj.productpriceUSD != product.productpriceUSD  || obj.productPrice != product.productPrice)
        {
          console.log("Price Has Changed")
          this.removeCartProduct(product);
        }
      }
    });
  }

  removeCartProduct(product: Product) {
    this.productService.removeLocalCartProduct(product);

    // Recalling
    this.getCartProduct();
  }

  goBack() {
    // window.history.back();
    this.location.back();

    console.log( 'goBack()...' );
  }
   getCartProduct() {
    this.cartProducts =  this.productService.getLocalCartProducts();
  }


  async getAllProducts() {

    const x = await this.productService.getProducts();
      this.productList = x;
    
    //console.log(this.bestProducts)
   // this.bestProducts = x;
    // x.snapshotChanges().subscribe(
    //   (product) => {

    //     this.bestProducts = [];
    //     for (let i = 0; i < 5; i++) {
    //       const y = product[i].payload.toJSON();
    //       y["$key"] = product[i].key;
    //       this.bestProducts.push(y as Product);
    //     }
    //     // product.forEach(element => {
    //     //   const y = element.payload.toJSON();
    //     //   y["$key"] = element.key;
    //     //   this.bestProducts.push(y as Product);
    //     // });
    //   },
    //   (error) => {
    //     this.toasterService.error("Error while fetching Products", error);
    //   }
    // );
  }
}
