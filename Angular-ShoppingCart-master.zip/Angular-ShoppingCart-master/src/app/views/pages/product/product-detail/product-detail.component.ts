import { Product } from "../../../../shared/models/product";
import { Component, OnInit, OnDestroy } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { ProductService } from "../../../../shared/services/product.service";
import { ToastrService } from "src/app/shared/services/toastr.service";
import { async } from 'q';
@Component({
  selector: "app-product-detail",
  templateUrl: "./product-detail.component.html",
  styleUrls: ["./product-detail.component.scss"],
})
export class ProductDetailComponent implements OnInit, OnDestroy {
  private sub: any;
  product: Product;
  products: Product[];

  constructor(
    private route: ActivatedRoute,
    private productService: ProductService,
    private toastrService: ToastrService
  ) {
    this.product = new Product();
  }

   ngOnInit() {
    this.sub =  this.route.params.subscribe(async(params) => {
      const id = params.id; // (+) converts string 'id' to a number
      //const x = await this.productService.getProductById(id);
      //this.product = x;
       this.getProductDetail(id);
    });
  }

 async getProductDetail(id: string) {
    // this.spinnerService.show();
    const x = await this.productService.getProductById(id);
   // x.$key = id;
   // this.product = x;
    
    // x.snapshotChanges().subscribe(
     //  (product) => {
    //     // this.spinnerService.hide();
         const y = x//.payload.toJSON() as Product;

         y.$Key = id;
         this.product = y[0];
         const z = await this.productService.getProducts();
         this.products = z;
        
    //   },
    //   (error) => {
    //     this.toastrService.error("Error while fetching Product Detail", error);
    //   }
    // );
  }

  addToCart(product: Product) {
    this.productService.addToCart(product,  this.products);
  }

  ngOnDestroy() {
    this.sub.unsubscribe();
  }
}
